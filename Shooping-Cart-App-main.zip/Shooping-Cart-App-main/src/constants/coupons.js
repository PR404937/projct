export const coupons = {
    SAVE10:{
        name:'SAVE10',
        discount:10
    },
    SAVE20:{
        name:'SAVE20',
        discount:20
    },
    ABCD:{
        name:'ABCD',
        discount:15
    }
}